INSERT INTO vehicle (vehicle_make, vehicle_model, vehicle_year, vehicle_cost, sales_person_id)
VALUES ('Giorgia', 'NINJA', 2017, 417826.20, 1);

INSERT INTO vehicle (vehicle_make, vehicle_model, vehicle_year, vehicle_cost, sales_person_id)
VALUES ('Pugito', 'Tumbler', 2018, 145842.20, 2);

INSERT INTO vehicle (vehicle_make, vehicle_model, vehicle_year, vehicle_cost, sales_person_id)
VALUES ('Cocanita', 'Titan', 2018, 18721.22, 3);

INSERT INTO vehicle (vehicle_make, vehicle_model, vehicle_year, vehicle_cost, sales_person_id)
VALUES ('EA', 'Cheetah', 2019, 18721.22,3);

INSERT INTO vehicle (vehicle_make, vehicle_model, vehicle_year, vehicle_cost, sales_person_id)
VALUES ('UBOAT', 'Ship', 2019, 24892.20, 4);

INSERT INTO vehicle (vehicle_make, vehicle_model, vehicle_year, vehicle_cost, sales_person_id)
VALUES ('HIT', 'Rocket', 2019, 24892.20, 4);

INSERT INTO vehicle (vehicle_make, vehicle_model, vehicle_year, vehicle_cost, sales_person_id)
VALUES ('SHIP', 'Delta', 2019, 5782.20, 5);