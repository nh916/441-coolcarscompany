INSERT INTO service(vehicle_id, service_mechanic_id, service_name, service_date_started, service_date_end)
VALUES (6, 6, 'suspension check', '2019-3-12', '2019-3-12');

INSERT INTO service(vehicle_id, service_mechanic_id, service_name, service_date_started, service_date_end)
VALUES (2, 6, 'oil change', '2019-3-21', '2019-3-21');

INSERT INTO service(vehicle_id, service_mechanic_id, service_name, service_date_started, service_date_end)
VALUES (3, 7, 'oil change', '2019-3-25', '2019-3-25');

INSERT INTO service(vehicle_id, service_mechanic_id, service_name, service_date_started, service_date_end)
VALUES (2, 7, 'air filter upgrade', '2019-4-02', '2019-4-22');

INSERT INTO service(vehicle_id, service_mechanic_id, service_name, service_date_started, service_date_end)
VALUES (1, 8, 'coolant change', '2019-4-12', '2019-4-13');

INSERT INTO service(vehicle_id, service_mechanic_id, service_name, service_date_started, service_date_end)
VALUES (6, 8, 'transmission replace', '2019-4-15', '2019-4-19');

INSERT INTO service(vehicle_id, service_mechanic_id, service_name, service_date_started, service_date_end)
VALUES (1, 9, 'suspension change', '2019-4-22', '2019-4-24');

INSERT INTO service(vehicle_id, service_mechanic_id, service_name, service_date_started, service_date_end)
VALUES (4, 9, 'CV joint change', '2019-5-8', '2019-5-12');

INSERT INTO service(vehicle_id, service_mechanic_id, service_name, service_date_started, service_date_end)
VALUES (5, 10, 'turbo maintenance', '2019-5-18', '2019-5-19');

INSERT INTO service(vehicle_id, service_mechanic_id, service_name, service_date_started, service_date_end)
VALUES (3, 10, 'oil change', '2019-6-22', '2019-6-22');
