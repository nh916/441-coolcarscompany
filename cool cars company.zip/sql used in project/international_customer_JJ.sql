INSERT INTO international_customer(international_customer_id, international_customer_country)
VALUES (6, 'Chile');

INSERT INTO international_customer(international_customer_id, international_customer_country)
VALUES (7, 'France');

INSERT INTO international_customer(international_customer_id, international_customer_country)
VALUES (8, 'Greece');

INSERT INTO international_customer(international_customer_id, international_customer_country)
VALUES (9, 'Japan');

INSERT INTO international_customer(international_customer_id, international_customer_country)
VALUES (10, 'Mexico');
