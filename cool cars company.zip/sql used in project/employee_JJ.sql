INSERT INTO employee(employee_name, employee_phone_number, employee_email, employee_date_hired, employee_type)
VALUES ('Abraham Kennedy', 5974784359, 'tmaek@me.com', '2017-04-01', 'sales');

INSERT INTO employee(employee_name, employee_phone_number, employee_email, employee_date_hired, employee_type)
VALUES ('Lorene Cannon', 6128891387, 'wmszeliga@mac.com', '2011-04-01', 'sales');

INSERT INTO employee(employee_name, employee_phone_number, employee_email, employee_date_hired, employee_type)
VALUES ('Ronald Saunders', 7203219940, 'johndo@yahoo.ca', '2012-04-01', 'sales');

INSERT INTO employee(employee_name, employee_phone_number, employee_email, employee_date_hired, employee_type)
VALUES ('Nicole Webb', 3698455909, 'quinn@gmail.com', '2013-04-01', 'sales');

INSERT INTO employee(employee_name, employee_phone_number, employee_email, employee_date_hired, employee_type)
VALUES ('Beatrice Morrison', 3188742111, 'shang@comcast.net', '2017-04-01', 'sales');

INSERT INTO employee(employee_name, employee_phone_number, employee_email, employee_date_hired, employee_type)
VALUES ('Charlene Williams', 6958416474, 'stecoop@optonline.net', '2014-04-01', 'mechanic');

INSERT INTO employee(employee_name, employee_phone_number, employee_email, employee_date_hired, employee_type)
VALUES ('Arlene Lyons', 6194572578, 'speeves@verizon.net', '2015-04-01', 'mechanic');

INSERT INTO employee(employee_name, employee_phone_number, employee_email, employee_date_hired, employee_type)
VALUES ('Antonia Barton', 4488908506, 'mwitte@optonline.net', '2012-04-01', 'mechanic');

INSERT INTO employee(employee_name, employee_phone_number, employee_email, employee_date_hired, employee_type)
VALUES ('Cristina Chandler', 3754965474, 'squirrel@yahoo.ca', '2014-04-01', 'mechanic');

INSERT INTO employee(employee_name, employee_phone_number, employee_email, employee_date_hired, employee_type)
VALUES ('Ronnie Ferguson', 2932422652, 'skippy@yahoo.com', '2018-04-01', 'mechanic');