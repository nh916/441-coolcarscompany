INSERT INTO part (part_name, part_price, supplier_id, mechanic_id)
VALUES ('Audi sport suspension', 1800, 1, 6);

INSERT INTO part (part_name, part_price, supplier_id, mechanic_id)
VALUES ('Bosch moto oil', 89, 2, 6);

INSERT INTO part (part_name, part_price, supplier_id, mechanic_id)
VALUES ('Drift LSD', 3200, 3, 7);

INSERT INTO part (part_name, part_price, supplier_id, mechanic_id)
VALUES ('performance tires', 1400, 4, 7);

INSERT INTO part (part_name, part_price, supplier_id, mechanic_id)
VALUES ('Anti-roll bar', 900, 5, 8);

INSERT INTO part (part_name, part_price, supplier_id, mechanic_id)
VALUES ('Brambo brake system', 3000, 6, 8);

INSERT INTO part (part_name, part_price, supplier_id, mechanic_id)
VALUES ('B Turbo', 5600, 7, 9);

INSERT INTO part (part_name, part_price, supplier_id, mechanic_id)
VALUES ('ECU unit', 4000, 8, 9);

INSERT INTO part (part_name, part_price, supplier_id, mechanic_id)
VALUES ('Suports package', 7000, 9, 10);

INSERT INTO part (part_name, part_price, supplier_id, mechanic_id)
VALUES ('Grip tires', 900, 10, 10);