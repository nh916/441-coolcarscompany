INSERT INTO mechanic (employee_id, mechanic_hourly_rate)
VALUES (6, 40.74);

INSERT INTO mechanic (employee_id, mechanic_hourly_rate)
VALUES (7, 37.45);

INSERT INTO mechanic (employee_id, mechanic_hourly_rate)
VALUES (8, 50.87);

INSERT INTO mechanic (employee_id, mechanic_hourly_rate)
VALUES (9, 43.71);

INSERT INTO mechanic (employee_id, mechanic_hourly_rate)
VALUES (10, 30.86);