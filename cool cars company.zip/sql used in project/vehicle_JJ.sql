INSERT INTO vehicle (vehicle_make, vehicle_model, vehicle_year, vehicle_cost)
VALUES ('Cool', 'TT1', 2015, 32000);

INSERT INTO vehicle (vehicle_make, vehicle_model, vehicle_year, vehicle_cost)
VALUES ('Cool', 'TT2', 2017, 34000);

INSERT INTO vehicle (vehicle_make, vehicle_model, vehicle_year, vehicle_cost)
VALUES ('Cool', 'TT3', 2018, 39000);

INSERT INTO vehicle (vehicle_make, vehicle_model, vehicle_year, vehicle_cost)
VALUES ('Cool', 'ST1', 2014, 42000);

INSERT INTO vehicle (vehicle_make, vehicle_model, vehicle_year, vehicle_cost)
VALUES ('Cool', 'ST2', 2016, 45000);

INSERT INTO vehicle (vehicle_make, vehicle_model, vehicle_year, vehicle_cost)
VALUES ('Cool', 'GT1', 2012, 72000);

INSERT INTO vehicle (vehicle_make, vehicle_model, vehicle_year, vehicle_cost)
VALUES ('Cool', 'GT2', 2014, 112000);

INSERT INTO vehicle (vehicle_make, vehicle_model, vehicle_year, vehicle_cost)
VALUES ('Cool', 'GT3', 2016, 202000);

INSERT INTO vehicle (vehicle_make, vehicle_model, vehicle_year, vehicle_cost)
VALUES ('Cool', 'FF', 2019, 332000);

INSERT INTO vehicle (vehicle_make, vehicle_model, vehicle_year, vehicle_cost)
VALUES ('Cool', 'FFS', 2020, 352000);