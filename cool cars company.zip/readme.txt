please enable PRAGMA when executing queries
check PRAGMA file for more details otherwise by default sqlite will not check foreign keys
    we want it to check

please save all sql code that you input

if you are not sure about something feel free to look it up or ask

I have included examples of all insertions

delete and drop file was just for me to use because I had to keep updating and
I didn't want to run everything one by one I just wanted to run in bulk

I think each table should have at least 10 data for best results

In most situations we will not be inputting primary key and pk will be inputted implicitly by
sqlite, but in some cases we will have to if it is a FK or a subtype of the supertype

please do not add onto the current scripts that i have sent
but make a new .sql file for each one. To make checking things later easier
example:
    Shonda_INSERT_vehicles.sql

If any errors within table that you think were a mistake, please report to Navid!

have fun