INSERT INTO sales_person (employee_id, sales_person_commission)
VALUES (1, 5634.12);
INSERT INTO sales_person (employee_id, sales_person_commission)
VALUES (2, 5799.83);
INSERT INTO sales_person (employee_id, sales_person_commission)
VALUES (3, 8514.22);
INSERT INTO sales_person (employee_id, sales_person_commission)
VALUES (4, 8730.48);
INSERT INTO sales_person (employee_id, sales_person_commission)
VALUES (5, 4355.93);