INSERT INTO employee_skill (employee_id, employee_skill)
    VALUES (1, 'Product Knowledge');
INSERT INTO employee_skill (employee_id, employee_skill)
    VALUES (1, 'Strategic Prospecting employee_skills');
INSERT INTO employee_skill (employee_id, employee_skill)
    VALUES (1, 'Active Listening');
INSERT INTO employee_skill (employee_id, employee_skill)
    VALUES (2, 'Product Knowledge');
INSERT INTO employee_skill (employee_id, employee_skill)
    VALUES (2, 'Communication');
INSERT INTO employee_skill (employee_id, employee_skill)
    VALUES (2, 'Qualification Questioning');
INSERT INTO employee_skill (employee_id, employee_skill)
    VALUES (3, 'Objection Handling');
INSERT INTO employee_skill (employee_id, employee_skill)
    VALUES (3, 'Strategic Prospecting employee_skills');
INSERT INTO employee_skill (employee_id, employee_skill)
    VALUES (3, 'Rapport Building on the Call');
INSERT INTO employee_skill (employee_id, employee_skill)
    VALUES (3, 'Qualification Questioning');
INSERT INTO employee_skill (employee_id, employee_skill)
    VALUES (4, 'Product Knowledge');
INSERT INTO employee_skill (employee_id, employee_skill)
    VALUES (4, 'Buyer-Seller Agreement');
INSERT INTO employee_skill (employee_id, employee_skill)
    VALUES (5, 'Objection Handling');
INSERT INTO employee_skill (employee_id, employee_skill)
    VALUES (5, 'Objection Prevention');
INSERT INTO employee_skill (employee_id, employee_skill)
    VALUES (5, 'Communication');
INSERT INTO employee_skill (employee_id, employee_skill)
    VALUES (6, 'Diagnostic employee_skills');
INSERT INTO employee_skill (employee_id, employee_skill)
    VALUES (6, 'Customer service employee_skills');
INSERT INTO employee_skill (employee_id, employee_skill)
    VALUES (6, 'Problem-solving employee_skills');
INSERT INTO employee_skill (employee_id, employee_skill)
    VALUES (6, 'Technical aptitude');
INSERT INTO employee_skill (employee_id, employee_skill)
    VALUES (7, 'Customer service employee_skills');
INSERT INTO employee_skill (employee_id, employee_skill)
    VALUES (7, 'Diagnostic employee_skills');
INSERT INTO employee_skill (employee_id, employee_skill)
    VALUES (7, 'Technical aptitude');
INSERT INTO employee_skill (employee_id, employee_skill)
    VALUES (7, 'Problem-solving employee_skills');
INSERT INTO employee_skill (employee_id, employee_skill)
    VALUES (8, 'Customer service employee_skills');
INSERT INTO employee_skill (employee_id, employee_skill)
    VALUES (8, 'Diagnostic employee_skills');
INSERT INTO employee_skill (employee_id, employee_skill)
    VALUES (9, 'Problem-solving employee_skills');
INSERT INTO employee_skill (employee_id, employee_skill)
    VALUES (9, 'Technical aptitude');
INSERT INTO employee_skill (employee_id, employee_skill)
    VALUES (10, 'Customer service employee_skills');
INSERT INTO employee_skill (employee_id, employee_skill)
    VALUES (10, 'Diagnostic employee_skills');
INSERT INTO employee_skill (employee_id, employee_skill)
    VALUES (10, 'Technical aptitude');
INSERT INTO employee_skill (employee_id, employee_skill)
    VALUES (10, 'Problem-solving employee_skills');