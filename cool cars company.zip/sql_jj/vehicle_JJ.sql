INSERT INTO vehicle (vehicle_make, vehicle_model, vehicle_year, vehicle_cost,  vehicle_sales_goal_for_current_year, vehicle_sales_goal_for_previous_year)
VALUES ('Cool', 'TT1', 2015, 32000, 200, 6000);
INSERT INTO vehicle (vehicle_make, vehicle_model, vehicle_year, vehicle_cost, vehicle_sales_goal_for_current_year, vehicle_sales_goal_for_previous_year)
VALUES ('Cool', 'TT2', 2017, 34000, 10000, 6000);
INSERT INTO vehicle (vehicle_make, vehicle_model, vehicle_year, vehicle_cost,vehicle_sales_goal_for_current_year, vehicle_sales_goal_for_previous_year)
VALUES ('Cool', 'TT3', 2018, 39000, 7000, 6000);
INSERT INTO vehicle (vehicle_make, vehicle_model, vehicle_year, vehicle_cost, vehicle_sales_goal_for_current_year, vehicle_sales_goal_for_previous_year)
VALUES ('Cool', 'ST1', 2014, 42000, 5000, 4000);
INSERT INTO vehicle (vehicle_make, vehicle_model, vehicle_year, vehicle_cost, vehicle_sales_goal_for_current_year, vehicle_sales_goal_for_previous_year)
VALUES ('Cool', 'ST2', 2016, 45000, 7000, 5000);
INSERT INTO vehicle (vehicle_make, vehicle_model, vehicle_year, vehicle_cost, vehicle_sales_goal_for_current_year, vehicle_sales_goal_for_previous_year)
VALUES ('Cool', 'GT1', 2012, 72000,3000, 2000);
INSERT INTO vehicle (vehicle_make, vehicle_model, vehicle_year, vehicle_cost, vehicle_sales_goal_for_current_year, vehicle_sales_goal_for_previous_year)
VALUES ('Cool', 'GT2', 2014, 112000, 1000, 300);
INSERT INTO vehicle (vehicle_make, vehicle_model, vehicle_year, vehicle_cost, vehicle_sales_goal_for_current_year, vehicle_sales_goal_for_previous_year)
VALUES ('Cool', 'GT3', 2016, 202000, 36, 7);
INSERT INTO vehicle (vehicle_make, vehicle_model, vehicle_year, vehicle_cost, vehicle_sales_goal_for_current_year, vehicle_sales_goal_for_previous_year)
VALUES ('Cool', 'FF', 2019, 332000, 8, 4);
INSERT INTO vehicle (vehicle_make, vehicle_model, vehicle_year, vehicle_cost, vehicle_sales_goal_for_current_year, vehicle_sales_goal_for_previous_year)
VALUES ('Cool', 'FFS', 2020, 352000, 3, 2);