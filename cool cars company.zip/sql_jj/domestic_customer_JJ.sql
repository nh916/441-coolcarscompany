INSERT INTO domestic_customer(domestic_customer_id, domestic_customer_state)
VALUES(1, 'CA');
INSERT INTO domestic_customer(domestic_customer_id, domestic_customer_state)
VALUES(2, 'NY');
INSERT INTO domestic_customer(domestic_customer_id, domestic_customer_state)
VALUES(3, 'NV');
INSERT INTO domestic_customer(domestic_customer_id, domestic_customer_state)
VALUES(4, 'MA');
INSERT INTO domestic_customer(domestic_customer_id, domestic_customer_state)
VALUES(5, 'CA');
