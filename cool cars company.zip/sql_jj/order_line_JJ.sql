INSERT INTO order_line (order_id, vehicle_id, order_quantity)
VALUES (1, 4, 8);
INSERT INTO order_line (order_id, vehicle_id, order_quantity)
VALUES (2, 1, 24);
INSERT INTO order_line (order_id, vehicle_id, order_quantity)
VALUES (3, 1, 32);
INSERT INTO order_line (order_id, vehicle_id, order_quantity)
VALUES (4, 4, 8);
INSERT INTO order_line (order_id, vehicle_id, order_quantity)
VALUES (5, 6, 2);
INSERT INTO order_line (order_id, vehicle_id, order_quantity)
VALUES (6, 2, 40);
INSERT INTO order_line (order_id, vehicle_id, order_quantity)
VALUES (7, 3, 3);
INSERT INTO order_line (order_id, vehicle_id, order_quantity)
VALUES (8, 5, 1);
INSERT INTO order_line (order_id, vehicle_id, order_quantity)
VALUES (9, 3, 5);
INSERT INTO order_line (order_id, vehicle_id, order_quantity)
VALUES (10, 5, 4);