INSERT INTO customer(customer_name, customer_phone_number, customer_street, customer_city, customer_zip_code, customer_type)
VALUES('Aaron Fuller', 7383670449, 'Pennsylvania Avenue', 19002, 'Grant', 'domestic');

INSERT INTO customer(customer_name, customer_phone_number, customer_street, customer_city, customer_zip_code, customer_type)
VALUES('Antonio Gross', 6674435742, 'Main customer_street South', 20744, 'Higganum', 'domestic');

INSERT INTO customer(customer_name, customer_phone_number, customer_street, customer_city, customer_zip_code, customer_type)
VALUES('Celia Young', 4238425859, 'Church customer_street', 30741, 'Wood River', 'domestic');

INSERT INTO customer(customer_name, customer_phone_number, customer_street, customer_city, customer_zip_code, customer_type)
VALUES('Wilson Goodwin', 5548581699, 'Fairview Avenue', 'Roy', 45840, 'domestic');

INSERT INTO customer(customer_name, customer_phone_number, customer_street, customer_city, customer_zip_code, customer_type)
VALUES('Leo Gill', 7184528143, 'Wall customer_street', 'Montross', 07026, 'domestic');

INSERT INTO customer(customer_name, customer_phone_number, customer_street, customer_city, customer_zip_code, customer_type)
VALUES('Reginald Hogan', 2833381181, 'Hudson customer_street', 'Marco Island', 11542, 'international');

INSERT INTO customer(customer_name, customer_phone_number, customer_street, customer_city, customer_zip_code, customer_type)
VALUES('Elijah Joseph', 9239375532, 'Highland Avenue', 'Virgelle', 27526, 'international');

INSERT INTO customer(customer_name, customer_phone_number, customer_street, customer_city, customer_zip_code, customer_type)
VALUES('Katie Brady', 3958198655, 'Dogwood Drive', 'Bienville', 16506, 'international');

INSERT INTO customer(customer_name, customer_phone_number, customer_street, customer_city, customer_zip_code, customer_type)
VALUES('Mona Drake', 2179153374, 'Heritage Drive', 'Carthage', 08527,'international');

INSERT INTO customer(customer_name, customer_phone_number, customer_street, customer_city, customer_zip_code, customer_type)
VALUES('Derrick Summers', 9768634277, '4th customer_street','Floyd', 07726, 'international');
