INSERT INTO supplier (company_name, supplier_phone_number, supplier_street, supplier_city, supplier_state, supplier_zip_code)
VALUES ('Audi', 6387622055, '71 Livingston St', 'Charlotte', 'NC', 28205);
INSERT INTO supplier (company_name, supplier_phone_number, supplier_street, supplier_city, supplier_state, supplier_zip_code)
VALUES ('Bosche', 7017801479, '87 Oak Valley Road', 'Brainerd', 'MN', 56401);
INSERT INTO supplier (company_name, supplier_phone_number, supplier_street, supplier_city, supplier_state, supplier_zip_code)
VALUES ('Titan', 9468600631, '7897 Roosevelt St.', 'Massapequa', 'NY', 11758);
INSERT INTO supplier (company_name, supplier_phone_number, supplier_street, supplier_city, supplier_state, supplier_zip_code)
VALUES ('YOKOHOMA', 5543431211, '784 High Noon St.', 'Solon', 'OH', 44139);
INSERT INTO supplier (company_name, supplier_phone_number, supplier_street, supplier_city, supplier_state, supplier_zip_code)
VALUES ('YAMAZAKI', 9297542285, '7922 Roosevelt Ave.', 'Ridgewood', 'NJ', 07450);
INSERT INTO supplier (company_name, supplier_phone_number, supplier_street, supplier_city, supplier_state, supplier_zip_code)
VALUES ('S1 moto sport club', 3887319886, '8904 Armstrong Lane', 'Montclair', 'NJ', 07042);
INSERT INTO supplier (company_name, supplier_phone_number, supplier_street, supplier_city, supplier_state, supplier_zip_code)
VALUES ('Bazuka', 5262312635, '44 Morris Ave', 'Westport', 'CT', 06880);
INSERT INTO supplier (company_name, supplier_phone_number, supplier_street, supplier_city, supplier_state, supplier_zip_code)
VALUES ('AMD', 6999955820, '935 St Margarets Drive', 'Millington', 'TN', 38053);
INSERT INTO supplier (company_name, supplier_phone_number, supplier_street, supplier_city, supplier_state, supplier_zip_code)
VALUES ('GRID', 3964893814, '8877 Snake Hill supplier_street', 'Fall River', 'MA', 02720);
INSERT INTO supplier (company_name, supplier_phone_number, supplier_street, supplier_city, supplier_state, supplier_zip_code)
VALUES ('TOYO', 2136244983, '8135 South Ave', 'Ellicott supplier_city', 'MD', 21042);