INSERT INTO orders (order_id, order_placement_date, order_shipment_date, customer_id)
VALUES (1, '2018-03-15' , '2018-03-17', 1);
INSERT INTO orders (order_id, order_placement_date, order_shipment_date, customer_id)
VALUES (2, '2018-03-15' , '2018-03-17', 1);
INSERT INTO orders (order_id, order_placement_date, order_shipment_date, customer_id)
VALUES (3, '2018-04-25' , '2018-05-3', 2);
INSERT INTO orders (order_id, order_placement_date, order_shipment_date, customer_id)
VALUES (4, '2018-05-06' , '2018-05-06', 3);
INSERT INTO orders (order_id, order_placement_date, order_shipment_date, customer_id)
VALUES (5, '2018-08-29' , '2018-09-03', 3);
INSERT INTO orders (order_id, order_placement_date, order_shipment_date, customer_id)
VALUES (6, '2018-010-17' , '2018-10-27', 4);
INSERT INTO orders (order_id, order_placement_date, order_shipment_date, customer_id)
VALUES (7, '2018-11-05' , '2018-11-07', 5);
INSERT INTO orders (order_id, order_placement_date, order_shipment_date, customer_id)
VALUES (8, '2018-12-05' , '2018-12-07', 6);
INSERT INTO orders (order_id, order_placement_date, order_shipment_date, customer_id)
VALUES (9, '2019-04-16' , '2019-04-17', 7);
INSERT INTO orders (order_id, order_placement_date, order_shipment_date, customer_id)
VALUES (10,  '2019-04-17' , '2019-04-20', 8);
