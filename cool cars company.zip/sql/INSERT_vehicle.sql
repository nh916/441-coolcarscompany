INSERT INTO vehicle (make,
                     model,
                     year,
                     cost,
                     vehicle_sales_goal_for_current_year,
                     vehicle_sales_goal_for_previous_year,
                     sales_person_id)
VALUES ('CoolCarsCompany', 'Joey', 2017, 417826.20, 10, 20, 6);



INSERT INTO vehicle (make,
                     model,
                     year,
                     cost,
                     vehicle_sales_goal_for_current_year,
                     vehicle_sales_goal_for_previous_year,
                     sales_person_id)
VALUES ('CoolCarsCompany', 'Tumbler', 2018, 145842.20, 5, 1, 7);



INSERT INTO vehicle (make,
                     model,
                     year,
                     cost,
                     vehicle_sales_goal_for_current_year,
                     vehicle_sales_goal_for_previous_year,
                     sales_person_id)
VALUES ('CoolCarsCompany', 'Titan', 2018, 18721.22, 3, 2, 8);


INSERT INTO vehicle (make,
                     model,
                     year,
                     cost,
                     vehicle_sales_goal_for_current_year,
                     vehicle_sales_goal_for_previous_year,
                     sales_person_id)
VALUES ('CoolCarsCompany', 'Cheetah', 2019, 18721.22, 3, 2, 8);


INSERT INTO vehicle (make,
                     model,
                     year,
                     cost,
                     vehicle_sales_goal_for_current_year,
                     vehicle_sales_goal_for_previous_year,
                     sales_person_id)
VALUES ('CoolCarsCompany', 'Ship', 2019, 24892.20, 10, 20, 9);


INSERT INTO vehicle (make,
                     model,
                     year,
                     cost,
                     vehicle_sales_goal_for_current_year,
                     vehicle_sales_goal_for_previous_year,
                     sales_person_id)
VALUES ('CoolCarsCompany', 'Rocket', 2019, 24892.20, 10, 20, 9);


INSERT INTO vehicle (make,
                     model,
                     year,
                     cost,
                     vehicle_sales_goal_for_current_year,
                     vehicle_sales_goal_for_previous_year,
                     sales_person_id)
VALUES ('CoolCarsCompany', 'Delta', 2019, 5782.20, 2, 20, 10);