INSERT INTO vehicle(make,
                    model,
                    year,
                    cost,
                    vehicle_sales_goal_for_current_year,
                    vehicle_sales_goal_for_previous_year
                    )
VALUES ('Lamborghini ', 'Aventador ', 2012, 417826.20, 10, 20);