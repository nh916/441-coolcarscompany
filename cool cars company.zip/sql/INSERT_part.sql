INSERT INTO part(part_name, price, mechanic_id)
VALUES ('duc tape', 189.94, 1);