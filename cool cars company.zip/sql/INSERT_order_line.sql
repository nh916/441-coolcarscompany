INSERT INTO order_line (product_id, order_id, order_quantity)
VALUES (1, 1, 10)