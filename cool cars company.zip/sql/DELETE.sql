DELETE FROM mechanic;
DELETE FROM sales_person;
DELETE FROM employee;
DELETE FROM supplier;
DELETE FROM part;
DELETE FROM vehicle

