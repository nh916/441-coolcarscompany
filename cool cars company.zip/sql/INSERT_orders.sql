INSERT INTO orders (order_placement_date, order_shipment_date, customer_id)
VALUES (2018-11-13, 2018-11-14, 1);

INSERT INTO orders (order_placement_date, order_shipment_date, customer_id)
VALUES (2018-11-13, 2018-11-14, 2);

INSERT INTO orders (order_placement_date, order_shipment_date, customer_id)
VALUES (2017-05-13, 2017-07-14, 3);

INSERT INTO orders (order_placement_date, order_shipment_date, customer_id)
VALUES (2017-04-13, 2017-05-14, 4);

INSERT INTO orders (order_placement_date, order_shipment_date, customer_id)
VALUES (2018-01-09, 2018-02-10, 5);

INSERT INTO orders (order_placement_date, order_shipment_date, customer_id)
VALUES (2017-05-02, 2017-06-11, 6);

INSERT INTO orders (order_placement_date, order_shipment_date, customer_id)
VALUES (2017-02-13, 2017-04-12, 7);

INSERT INTO orders (order_placement_date, order_shipment_date, customer_id)
VALUES (2018-02-12, 2018-02-15, 8);

INSERT INTO orders (order_placement_date, order_shipment_date, customer_id)
VALUES (2018-03-08, 2018-03-12, 9);

INSERT INTO orders (order_placement_date, order_shipment_date, customer_id)
VALUES (2018-04-12, 2018-04-15, 10);

INSERT INTO orders (order_placement_date, order_shipment_date, customer_id)
VALUES (2018-03-12, 2018-03-15, 8);