INSERT INTO orders (customer_id)
VALUES (1);
