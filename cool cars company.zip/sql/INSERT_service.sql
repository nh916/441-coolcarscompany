INSERT INTO service(vehicle_id, mechanic_id, service_name)
VALUES (1, 1, 'bubble_bath')

INSERT INTO service(vehicle_id, mechanic_id, service_name)
VALUES (1, 1, 'bubble_bath')

INSERT INTO service(vehicle_id, mechanic_id, service_name, service_date_started, service_date_end)
VALUES (1, 1, 'bubble_bath', '2018-11-13', '2018-10-02')