
INSERT INTO supplier(
                    company_name,
                    phone_number,
                     street,
                     city,
                     state,
                     zip_code
                     )
VALUES ('Doofenshmirtz Evil Inc', 818658261, 'Prairie', 'Northridge', 'CA', '913084');

    INSERT INTO part (part_name, price, supplier_id, mechanic_id)
    VALUES ('Headlights ', 50.99, 1, 1);


INSERT INTO supplier (company_name, phone_number, street, city, state, zip_code)
VALUES ('Jobba', 81848462, 'Wall Street', 'New York City', 'NY', '484218');

    INSERT INTO part (part_name, price, supplier_id, mechanic_id)
    VALUES ('Engine', 54560.99, 2, 2);



INSERT INTO supplier (company_name, phone_number, street, city, state, zip_code)
VALUES ('Auto Parts', 81888245, 'Broadway', 'New York City', 'NY', '487246');

    INSERT INTO part (part_name, price, supplier_id, mechanic_id)
    VALUES ('Brakes', 415.99, 3, 3);



INSERT INTO supplier (company_name, phone_number, street, city, state, zip_code)
VALUES ('Auto Zone', 81824821, 'Hollywood Boulevard', 'Los Angeles', 'CA', '679421');

    INSERT INTO part (part_name, price, supplier_id, mechanic_id)
    VALUES ('Wheels', 4652.99, 4, 4);


INSERT INTO supplier (company_name, phone_number, street, city, state, zip_code)
VALUES ('Auto Joe', 81845428, 'Las Vegas Boulevard', 'Las Vegas', 'NV', '679421');

    INSERT INTO part (part_name, price, supplier_id, mechanic_id)
    VALUES ('Tire', 4652.99, 5, 5);







    INSERT INTO part (part_name, price, supplier_id, mechanic_id)
    VALUES ('Clutch', 2346.99, 3, 5);


    INSERT INTO part (part_name, price, supplier_id, mechanic_id)
    VALUES ('Clutch', 2346.99, 3, 5);



    INSERT INTO part (part_name, price, supplier_id, mechanic_id)
    VALUES ('Brake fluid', 2379.99, 4, 3);

    INSERT INTO part (part_name, price, supplier_id, mechanic_id)
    VALUES ('Alternator', 1234.99, 2, 4);