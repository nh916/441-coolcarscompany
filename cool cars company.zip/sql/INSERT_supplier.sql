
INSERT INTO supplier(
                    company_name,
                    phone_number,
                     street,
                     city,
                     state,
                     zip_code,
                     part_id
                     )
VALUES ('Doofenshmirtz Evil Inc', 818658261, 'Pararie', 'New York City', 'NY', '913084', 1);