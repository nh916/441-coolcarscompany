DROP TABLE mechanic;
DROP TABLE sales_person;
DROP TABLE employee;
DROP TABLE supplier;
DROP TABLE part;
DROP TABLE service;
