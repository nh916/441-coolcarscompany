-- checks to see if its turned off or on
PRAGMA foreign_keys;
-- 1 is on
-- 0 is off

-- turn on
PRAGMA foreign_keys = ON;

-- turn off
PRAGMA foreign_keys = ON;